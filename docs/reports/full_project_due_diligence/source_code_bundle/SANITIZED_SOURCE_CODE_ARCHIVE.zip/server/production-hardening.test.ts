import { describe, expect, it } from "vitest";
import { assertProductionEnv, validateProductionEnv } from "./_core/env";
import { createSessionToken } from "./_core/session";

function productionEnv(overrides: NodeJS.ProcessEnv = {}): NodeJS.ProcessEnv {
  return {
    NODE_ENV: "production",
    JWT_SECRET: "0123456789abcdef0123456789abcdef",
    DATABASE_URL: "mysql://user:password@example.com:3306/rawahel",
    OAUTH_SERVER_URL: "https://auth.example.com",
    VITE_APP_ID: "rawahel-pulse",
    EXTERNAL_SUBMISSION_BASE_URL: "https://pulse.example.com",
    ...overrides,
  };
}

async function withEnv<T>(patch: NodeJS.ProcessEnv, fn: () => Promise<T>) {
  const previous: Record<string, string | undefined> = {};
  for (const key of Object.keys(patch)) previous[key] = process.env[key];
  try {
    for (const [key, value] of Object.entries(patch)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
    return await fn();
  } finally {
    for (const [key, value] of Object.entries(previous)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  }
}

describe("production hardening", () => {
  it("fails production readiness when required auth or database env is missing", () => {
    const result = validateProductionEnv(productionEnv({
      JWT_SECRET: "",
      DATABASE_URL: "",
      OAUTH_SERVER_URL: "",
    }));

    expect(result.ok).toBe(false);
    expect(result.missing).toEqual(expect.arrayContaining([
      "JWT_SECRET",
      "DATABASE_URL",
      "OAUTH_SERVER_URL",
    ]));
  });

  it("rejects weak JWT secrets and half-configured remote storage", () => {
    const result = validateProductionEnv(productionEnv({
      JWT_SECRET: "too-short",
      BUILT_IN_FORGE_API_URL: "https://forge.example.com",
      BUILT_IN_FORGE_API_KEY: "",
    }));

    expect(result.ok).toBe(false);
    expect(result.invalid).toEqual(expect.arrayContaining([
      "JWT_SECRET must be at least 32 characters",
      "BUILT_IN_FORGE_API_URL and BUILT_IN_FORGE_API_KEY must be configured together",
    ]));
  });

  it("accepts a complete production environment and keeps optional storage as a warning only", () => {
    const result = assertProductionEnv(productionEnv({
      BUILT_IN_FORGE_API_URL: "",
      BUILT_IN_FORGE_API_KEY: "",
    }));

    expect(result.ok).toBe(true);
    expect(result.missing).toHaveLength(0);
    expect(result.invalid).toHaveLength(0);
    expect(result.warnings).toContain("Remote export storage is not configured; local PDF/PNG export fallback remains enabled");
  });

  it("does not sign production sessions with the local fallback secret", async () => {
    await withEnv({
      NODE_ENV: "production",
      JWT_SECRET: "",
      VITE_APP_ID: "rawahel-pulse",
    }, async () => {
      await expect(createSessionToken("prod-user", { name: "Production User" })).rejects.toThrow(/JWT_SECRET/);
    });
  });
});
